A = [1 2;
     2 8;
     3 12];


rref(A)
null(A)
rats(null(A'))
